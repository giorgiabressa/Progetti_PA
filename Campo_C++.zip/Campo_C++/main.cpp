#include "Volontario.h"
#include "CapoSquadra.h"
#include "VolontarioSemplice.h"
#include "Gruppo.h"
#include "Veicolo.h"
#include "GestioneGruppi.h"
#include <iostream>
#include <string>
#include <vector>
#include <memory>

using namespace std;

int stampaMenu();

int main(){
	GestioneGruppi *gestionale = GestioneGruppi::instance();
	bool ins = true;
	int sel;

	cerr << "++++++++ GESTIONALE GRUPPI PROTEZIONE CIVILE ++++++++" << endl;

	gestionale->nuovoGruppo();

	while(ins){
		sel = stampaMenu();

		switch(sel){
		case 0:		ins = false;							break;
		case 1:		gestionale->nuovoGruppo();				break;
		case 2:		gestionale->nuovoCapoSquadra();			break;
		case 3:		gestionale->nuovoVolontarioSemplice();	break;
		case 4:		gestionale->nuovoVeicolo();				break;
		case 5:		gestionale->eliminaGruppo();			break;
		case 6:		gestionale->eliminaVolontario();		break;
		case 7:		gestionale->eliminaVeicolo();			break;
		case 8:		gestionale->calcolaRimborsoVeicolo();	break;
		case 9: 	gestionale->toStringGruppi();			break;
		case 10:	gestionale->toStringVolontari();		break;
		case 11:	gestionale->toStringVeicoli();			break;
		default:	cout << "Errore, selezione non accettata" << endl;
		}
	}
	return 0;
}





int stampaMenu(){
	int selezione;
	cout << endl;
	cerr << "Selezionare l'operazione desiderata: " << endl;
	cout << "1: Inserimento di un nuovo gruppo" << endl;
	cout << "2: Inserimento di un capo squadra" << endl;
	cout << "3: Inserimento di un volontario semplice" << endl;
	cout << "4: Inserimento di un veicolo" << endl;
	cout << "5: Cancellazione di un gruppo" << endl;
	cout << "6: Cancellazione di un volontario" << endl;
	cout << "7: Cancellazione di un veicolo" << endl;
	cout << "8: Calcola il rimborso di un veicolo" << endl;
	cout << "9: Stampa gruppi registrati" << endl;
	cout << "10: Stampa volontari registrati" << endl;
	cout << "11: Stampa veicoli registrati" << endl;
	cout << "0: ESCI DAL GESTIONALE" << endl;

	cin >> selezione;
	return selezione;
}
