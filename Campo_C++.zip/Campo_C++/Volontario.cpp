#include "Volontario.h"
#include <string>
#include <iostream>

using namespace std;

Volontario::Volontario(string n, string c) {
	nome = n;
	cognome = c;
}

string Volontario::getCognome(){
	return cognome;
}

string Volontario::getNome(){
	return nome;
}

void Volontario::toString(){
	string stampa = "Volontario:\t"+cognome+"\t"+nome;
	cout << stampa << endl;
}

Volontario::~Volontario() {
	cout << "-> Cancellazione Volontario in corso..." << endl;
}

