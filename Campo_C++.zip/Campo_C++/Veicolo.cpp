#include "Veicolo.h"
#include <cstring>
#include <iostream>
#include <string>

using namespace std;

const double Veicolo::PREZZO_CARBURANTE = 2.0;

Veicolo::Veicolo(string ma, string mo, string ta, double km, double con) {
	marca = ma;
	modello = mo;
	targa = ta;

	chilometri_veicolo = km;
	consumo = con;
	chilometri_percorsi = 0;
}

double Veicolo::calcolaRimborso(){
	chilometri_veicolo += chilometri_percorsi;
	double temp = chilometri_percorsi;
	chilometri_percorsi = 0;
	return (PREZZO_CARBURANTE / consumo) * temp;
}

void Veicolo::toString(){
	string stampa = "Veicolo:\t"+marca+"\t"+modello+"\t"+targa+"\tKM: ";
	cout << stampa << chilometri_veicolo << endl;
}

Veicolo::~Veicolo() {
	cout << "-> Cancellazione veicolo in corso..." << endl;
}

