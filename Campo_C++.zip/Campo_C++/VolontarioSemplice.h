#ifndef VOLONTARIOSEMPLICE_H_
#define VOLONTARIOSEMPLICE_H_

#include "Volontario.h"
#include <string>

using namespace std;

class VolontarioSemplice : public Volontario{
public:
	VolontarioSemplice(string, string);
	virtual ~VolontarioSemplice();
};


#endif /* VOLONTARIOSEMPLICE_H_ */
