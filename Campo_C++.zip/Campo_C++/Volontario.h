#ifndef VOLONTARIO_H_
#define VOLONTARIO_H_

#include <string>
#include <iostream>

using namespace std;

class Volontario {
protected:
	string nome, cognome;
public:
	Volontario(string, string);
	virtual string getNome();
	virtual string getCognome();
	virtual void toString();
	virtual ~Volontario();
};

#endif /* VOLONTARIO_H_ */
