#include "VolontarioSemplice.h"
#include <string>

using namespace std;

VolontarioSemplice::VolontarioSemplice(string n, string c) :
		Volontario(n, c) {}

VolontarioSemplice::~VolontarioSemplice(){
	cout << "-> Cancellazione Volontario Semplice in corso..." << endl;
}
