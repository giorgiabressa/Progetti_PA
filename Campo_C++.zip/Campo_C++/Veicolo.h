#ifndef VEICOLO_H_
#define VEICOLO_H_

#include <string>
using namespace std;

class Veicolo {
private:
	static const double PREZZO_CARBURANTE;
	string marca, modello, targa;
	double chilometri_veicolo;
	double chilometri_percorsi;
	double consumo;

public:
	Veicolo(string, string, string, double, double);

	inline void addKmpercorsi(double km)	{chilometri_percorsi += km;}

	inline double getKmVeicolo()			{return chilometri_veicolo;}
	inline double getKmPercorsi()			{return chilometri_percorsi;}
	inline string getTarga()				{return targa;}

	double calcolaRimborso();
	void toString();

	virtual ~Veicolo();
};



#endif /* VEICOLO_H_ */
