#ifndef GRUPPO_H_
#define GRUPPO_H_

#include "Volontario.h"
#include "Veicolo.h"
#include <string>
#include <iostream>
#include <memory>
#include <vector>

using namespace std;

class Gruppo {
private:
	string nome;
	unique_ptr<Volontario> presidente;

	vector<unique_ptr<Veicolo>> veicoli;
	vector<unique_ptr<Volontario>> volontari;

public:
	Gruppo(string, Volontario*);
	void aggiungiVolontario(Volontario*);
	void aggiungiVeicolo(Veicolo*);

	inline string getNome() { return nome; }
	vector<unique_ptr<Veicolo>>& getVeicoli();
	vector<unique_ptr<Volontario>>& getVolontari();

	void toStringVeicoli();
	void toStringVolontari();

	virtual ~Gruppo();
};

#endif /* GRUPPO_H_ */
