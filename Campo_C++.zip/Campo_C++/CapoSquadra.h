#ifndef CAPOSQUADRA_H_
#define CAPOSQUADRA_H_

#include "Volontario.h"
#include <string>
#include <iostream>

class CapoSquadra : public Volontario{
private:
	string numero_telefono;
public:
	CapoSquadra(string, string, string);
	string getNumeroTelefono();
	inline void setNumero(string num) {numero_telefono = num; }
	void toString();
	virtual ~CapoSquadra();
};



#endif /* CAPOSQUADRA_H_ */
