#include "Gruppo.h"
#include "Volontario.h"
#include "Veicolo.h"
#include <string>
#include <vector>
#include <memory>

using namespace std;

Gruppo::Gruppo(string n, Volontario *pres) {
	//viene passato un raw pointer per rendere possibile l'utilizzo degli smart pointers
	nome = n;
	unique_ptr<Volontario> pt_pres (pres);
	presidente = move(pt_pres);

	volontari.push_back(move(presidente));
}

void Gruppo::aggiungiVolontario(Volontario *vol){
	unique_ptr<Volontario> vol_pt (vol);
	volontari.push_back(move(vol_pt));
}

void Gruppo::aggiungiVeicolo(Veicolo *ve){
	unique_ptr<Veicolo> ve_pt (ve);
	veicoli.push_back(move(ve_pt));
}

vector<unique_ptr<Veicolo>>& Gruppo::getVeicoli(){
	return veicoli;
}

vector<unique_ptr<Volontario>>& Gruppo::getVolontari(){
	return volontari;
}

void Gruppo::toStringVeicoli(){
	cout << "VEICOLI APPARTENENTI AL GRUPPO " << nome << endl;
	for(auto &v : veicoli){
		v->toString();
	}
}

void Gruppo::toStringVolontari(){
	cout << "VOLONTARI REGISTRATI AL GRUPPO " << nome << endl;
	for(auto &v : volontari){
		v->toString();
	}
}

Gruppo::~Gruppo() {
	cout << "-> Cancellazione gruppo in corso..." << endl;
	veicoli.clear();
	volontari.clear();
}

