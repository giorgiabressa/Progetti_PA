#include "Volontario.h"
#include "Gruppo.h"
#include "Veicolo.h"
#include "GestioneGruppi.h"
#include "VolontarioSemplice.h"
#include "CapoSquadra.h"
#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <algorithm>

using namespace std;

GestioneGruppi* GestioneGruppi::gestionale = NULL;

GestioneGruppi::GestioneGruppi(){ }

void GestioneGruppi::nuovoGruppo(){
	string n_gr, n_v, c_v;
	cout << "------ INSERIMENTO NUOVO GRUPPO ------" << endl;
	cout << "Inserire nome gruppo: ";
	cin >> n_gr;

	cout << "Inserire nome presidente: ";
	cin >> n_v;

	cout << "Inserire cognome presidente: ";
	cin >> c_v;

	Volontario *pres = new Volontario(n_v, c_v);
	unique_ptr<Gruppo> gr_sp (new Gruppo(n_gr, pres));

	gruppi.push_back(move(gr_sp));

	cout << "***** GRUPPO INSERITO *****" << endl;
}

void GestioneGruppi::nuovoVeicolo(){
	string marca, modello, targa;
	int gruppo = selezioneGruppo();

	double km, cons;
	cout << "----- INSERIMENTO NUOVO VEICOLO -----" << endl;
	cout << "Inserire marca veicolo: ";
	cin >> marca;

	cout << "Inserire modello veicolo: ";
	cin >> modello;

	cout << "Inserire targa veicolo: ";
	cin >> targa;

	cout << "Inserire chilometraggio veicolo: ";
	cin >> km;

	cout << "Inserire consumo veicolo: ";
	cin >> cons;

	Veicolo *ve = new Veicolo(marca, modello, targa, km, cons);
	gruppi.at(gruppo)->aggiungiVeicolo(ve);

	cout << "***** VEICOLO INSERITO *****" << endl;
}

void GestioneGruppi::nuovoVolontarioSemplice(){
	string nome, cognome;
	int gruppo = selezioneGruppo();

	cout << "----- INSERIMENTO NUOVO VOLONTARIO SEMPLICE -----" << endl;
	cout << "Inserire nome volontario: ";
	cin >> nome;

	cout << "Inserire cognome volontario: ";
	cin >> cognome;

	VolontarioSemplice *vs = new VolontarioSemplice(nome, cognome);
	gruppi.at(gruppo)->aggiungiVolontario(vs);

	cout << "***** VOLONTARIO SEMPLICE INSERITO *****" << endl;
}

void GestioneGruppi::nuovoCapoSquadra(){
	string nome, cognome, tel;
	int gruppo = selezioneGruppo();

	cout << "----- INSERIMENTO NUOVO CAPOSQUADRA -----" << endl;
	cout << "Inserire nome capo squadra: ";
	cin >> nome;

	cout << "Inserire cognome capo squadra: ";
	cin >> cognome;

	cout << "Inserire numero di telefono capo squadra: ";
	cin >> tel;

	CapoSquadra *cs = new CapoSquadra(nome, cognome, tel);
	gruppi.at(gruppo)->aggiungiVolontario(cs);

	cout << "***** CAPO SQUADRA INSERITO *****" << endl;
}

void GestioneGruppi::calcolaRimborsoVeicolo(){
	Posizioni pos = selezioneVeicolo();
	double km;

	cout << "Inserire chilometri percorsi: ";
	cin >> km;

	gruppi.at(pos.gruppo)->getVeicoli().at(pos.variabile)->addKmpercorsi(km);
	double rimborso = gruppi.at(pos.gruppo)->getVeicoli().at(pos.variabile)->calcolaRimborso();

	string targa = gruppi.at(pos.gruppo)->getVeicoli().at(pos.variabile)->getTarga();

	cout << "Veicolo con targa: " << targa << "\tRimborso: " << rimborso << " �" << endl;
}

void GestioneGruppi::eliminaGruppo(){
	gruppi.erase(gruppi.begin() + selezioneGruppo());
	cout << "***** GRUPPO ELIMINATO *****" << endl;
}

void GestioneGruppi::eliminaVeicolo(){
	Posizioni pos = selezioneVeicolo();

	//cout << "gruppo: " << pos.gruppo << "   veicolo: " << pos.variabile << endl;

	gruppi.at(pos.gruppo)->getVeicoli().erase(gruppi.at(pos.gruppo)->getVeicoli().begin() + pos.variabile);
	cout << "***** VEICOLO ELIMINATO *****" << endl;
}

void GestioneGruppi::eliminaVolontario(){
	Posizioni pos = selezioneVolontario();

	gruppi.at(pos.gruppo)->getVolontari().erase(gruppi.at(pos.gruppo)->getVolontari().begin() + pos.variabile);
	cout << "***** VOLONTARIO ELIMINATO *****" << endl;
}

void GestioneGruppi::toStringGruppi(){
	cout << "-- Stampa gruppi registrati -----------------------------" << endl;
	for_each(gruppi.begin(), gruppi.end(), [] (unique_ptr<Gruppo> &gr){
		cout << gr->getNome() << endl;
	});
	cout << "---------------------------------------------------------" << endl;
}

void GestioneGruppi::toStringVeicoli(){
	cout << "-- Stampa veicoli registrati ----------------------------" << endl;
	for_each(gruppi.begin(), gruppi.end(), [] (unique_ptr<Gruppo> &gr){
		gr->toStringVeicoli();
	});
	cout << "---------------------------------------------------------" << endl;
}

void GestioneGruppi::toStringVolontari(){
	cout << "-- Stampa volontari registrati --------------------------" << endl;
	for_each(gruppi.begin(), gruppi.end(), [] (unique_ptr<Gruppo> &gr){
		gr->toStringVolontari();
	});
	cout << "---------------------------------------------------------" << endl;
}

int GestioneGruppi::selezioneGruppo(){
	int cont = 0, selezione;
	for(auto &gr : gruppi){
		cout << cont << ": " << gr->getNome() << endl;
		cont++;
	}

	cout << "Selezionare il numero corrispondente al gruppo desiderato: ";
	cin >> selezione;

	return selezione;
}

Posizioni GestioneGruppi::selezioneVeicolo(){
	Posizioni pos;
	int gruppo = 0, cont = 0, selezione;
	for(auto &gr : gruppi){
		for(auto &ve : gr->getVeicoli()){
			cout << cont << ": ";
			ve->toString();
			cont++;
		}
		gruppo++;
	}

	cout << "Selezionare il numero corrispondente al veicolo desiderato: ";
	cin >> selezione;

	pos.gruppo = gruppo - 1;
	pos.variabile = selezione;

	return pos;
}

Posizioni GestioneGruppi::selezioneVolontario(){
	int gruppo = 0, cont = 0, selezione;
	Posizioni pos;

	for(auto &gr : gruppi){
		for(auto &vo : gr->getVolontari()){
			cout << cont << ": ";
			vo->toString();
			cont++;
		}
		gruppo++;
	}

	cout << "Selezionare il numero corrispondente al volontario desiderato: ";
	cin >> selezione;

	pos.gruppo = gruppo - 1;
	pos.variabile = selezione;

	return pos;
}
