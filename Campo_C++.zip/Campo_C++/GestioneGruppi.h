#ifndef CAMPO_H_
#define CAMPO_H_

#include "Volontario.h"
#include "Gruppo.h"
#include "Veicolo.h"
#include <iostream>
#include <string>
#include <vector>
#include <memory>

using namespace std;

struct Posizioni{
	int gruppo;
	int variabile;
};

class GestioneGruppi{
private:
	vector<unique_ptr<Gruppo>> gruppi;
	static GestioneGruppi *gestionale;

	GestioneGruppi();

	int selezioneGruppo();
	Posizioni selezioneVeicolo();
	Posizioni selezioneVolontario();
public:
	static GestioneGruppi* instance(){
		if(gestionale == NULL)
			gestionale = new GestioneGruppi();
		return gestionale;
	}

	GestioneGruppi(GestioneGruppi const&) = delete;

	void nuovoGruppo();
	void nuovoVeicolo();
	void nuovoVolontarioSemplice();
	void nuovoCapoSquadra();

	void calcolaRimborsoVeicolo();

	void eliminaGruppo();
	void eliminaVeicolo();
	void eliminaVolontario();

	void toStringGruppi();
	void toStringVeicoli();
	void toStringVolontari();
};


#endif /* CAMPO_H_ */
