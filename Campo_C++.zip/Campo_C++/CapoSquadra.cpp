#include "Volontario.h"
#include "CapoSquadra.h"
#include <string>
#include <iostream>

using namespace std;

CapoSquadra::CapoSquadra(string n, string c, string tel) :
		Volontario(n, c){
	numero_telefono = tel;
}

string CapoSquadra::getNumeroTelefono(){
	return numero_telefono;
}

void CapoSquadra::toString(){
	string stampa = "Capo Squadra:\t"+cognome+"\t"+nome+"\t\t\tContatto: "+numero_telefono;
	cout << stampa << endl;
}

CapoSquadra::~CapoSquadra(){
	cout << "-> Cancellazione Capo Squadra in corso..." << endl;
}
