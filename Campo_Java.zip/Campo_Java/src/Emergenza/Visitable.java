package Emergenza;

public interface Visitable {
	public double accept(Visitor v);
}
