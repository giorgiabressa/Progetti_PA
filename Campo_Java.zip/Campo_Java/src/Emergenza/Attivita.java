package Emergenza;

import java.util.ArrayList;

/**
 * Classe utilizzata per la gestione delle attivit� in corso durante l'emergenza.
 */
public class Attivita {
	private String descrizione;
	private ArrayList<Veicolo> veicoli;
	private ArrayList<Volontario> volontari;
	
	public Attivita(String des) {
		this.descrizione = des;
		this.veicoli = new ArrayList<>();
		this.volontari = new ArrayList<>();
	}
	
	/**
	 * 	METODI GET
	 */
	public String getDesc() 					{	return this.descrizione;	}
	public ArrayList<Volontario> getVolontari()	{	return volontari;			}
	public ArrayList<Veicolo> getVeicoli()		{	return veicoli;				}
	
	/**
	 * METODI AGGIUNTA VOLONTARI E VEICOLI
	 * 
	 * In entrambi i metodi vengono utilizzati i Varargs.
	 * Oltre ad associare il volontario/veicolo all'attivit�, gestisce direttamente anche lo stato di tali oggetti.
	 */
	public void addVolontari(Volontario...v) {
		for (int i = 0; i < v.length; i++) {
			v[i].inizioAttivita();						// Il Volontario viene segnalato "in attivit�"
			volontari.add(v[i]);
		}
	}
	
	public void addVeicoli(Veicolo...v) {
		for (int i = 0; i < v.length; i++) {			// Il Veicolo viene segnalato "in attivit�"
			v[i].inizioAttivita();
			veicoli.add(v[i]);
		}
	}
	
	/**
	 * METODO PER LA FINE E CHIUSURA ATTIVITA
	 * 
	 * Tutti i veicoli e volontari associati a questa attivit� vengono resi nuovamente disponibili
	 */
	public void fineAttivita(int ore, double km) {
		for (Veicolo veicolo : veicoli) {
			veicolo.fineAttivita(km);
		}
		
		for (Volontario vol : volontari) {
			vol.fineAttivita(ore);
		}
	}
	
	/**
	 * METODI TO STRING
	 */
	public String toStringVeicoli() {
		String stampa = "Veicoli occupati nell'attivit� '"+descrizione+"':\n";
		for (Veicolo veicolo : veicoli) {
			stampa += veicolo.toString();
		}
		return stampa;
	}
	
	public String toStringVolontari() {
		String stampa = "Volontaari occupati nell'attivit� '"+descrizione+"':\n";
		for (Volontario vol : volontari) {
			stampa += vol.toString();
		}
		return stampa;
	}
}
