package Emergenza;

/**
 * Classe CAPO SQUADRA che eredita dalla classe astratta VOLONTARIO
 * Aggiunge un solo parametro: numeroTelefono
 */
public class CapoSquadra extends Volontario{
	private String numeroTelefono;
	
	/**
	 * Nel costruttore deve esserci il riferimento al costruttore della classe da cui eredita
	 */
	public CapoSquadra(String cognome, String nome, String numero) {
		super(cognome, nome);
		this.numeroTelefono = numero;
	}
	
	/**
	 * METODO ACCEPT per permettere l'utilizzo del Visitor Pattern
	 */
	public double accept(Visitor v) 	{	return v.visit(this);		}
	
	/**
	 * METODO GET
	 */
	public String getNumeroTelefono() 	{	return this.numeroTelefono;	}
	
	/**
	 * Ovverride del metodo toString()
	 */
	public String toString() {
		return "Capo Squadra:\t"+super.cognome+"\t"+super.nome+"\n";
	}
}
