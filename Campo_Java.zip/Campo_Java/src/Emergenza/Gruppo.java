package Emergenza;

import java.util.ArrayList;

/**
 * Classe GRUPPO per la gestione delle varie operazioni sul singolo gruppo.
 */
public class Gruppo {
	private String nome;
	private ArrayList<Veicolo> veicoli;
	private ArrayList<Volontario> volontari;
	
	public Gruppo(String nome) {
		this.nome = nome.toUpperCase();
		veicoli = new ArrayList<>();
		volontari = new ArrayList<>();
	}
	
	/**
	 * METODI DI AGGIUNTA VOLONTARI E VEICOLI, con overload per l'inserimento dei volontari.
	 */
	public void aggiungiVolontario(Volontario v){
		volontari.add(v);
	}
	
	public void aggiungiVolontario(String cognome, String nome) {
		volontari.add(new VolontarioSemplice(cognome, nome));
	}
	
	public void aggiungiVolontario(String cognome, String nome, String numero) {
		volontari.add(new CapoSquadra(cognome, nome, numero));
	}
	
	public void aggiungiVeicolo(Veicolo v) {
		veicoli.add(v);
	}

	/**
	 * METODI GET 
	 */
	public ArrayList<Veicolo> getVeicoli()		{	return this.veicoli;	}	
	public ArrayList<Volontario> getVolontari()	{	return this.volontari;	}
	
	/**
	 * METODO PER USCITA definiva del gruppo, ogni veicolo e volontario viene reso disponibile.
	 */
	public void uscitaDefinitiva() {
		for (Veicolo ve : veicoli)
			ve.uscitaDefinitiva();
		
		for (Volontario vol : volontari)
			vol.uscitaDefinitiva();
	}
	
	/**
	 * Override del metodo toString()
	 */
	public String toString() {
		return "Gruppo "+this.nome+"\n";
	}
}
