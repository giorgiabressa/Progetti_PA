package Emergenza;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GestioneCampo {

	public static void main(String[] args) throws IOException {
		boolean menu = true;
		int scelta;
		Campo campo = Campo.instance();
		
		popolaCampo();
		
		while(menu) {
			pulisciConsole();
			scelta = stampaMenu();			
			switch (scelta) {
			case 0:	menu = false;									break;
			case 1:	System.out.println(campo.toString());			break;
			case 2:	System.out.println(campo.toStringVolontari());	break;
			case 3: System.out.println(campo.toStringVeicoli());	break;
			case 4:	gestisciAttivita();								break;
			case 5:	gestisciRimborsi();								break;

			default:System.err.println("Scelta non accettata");	break;
			}
		}
		campo.chiusuraEmergenza();
		System.out.println("Emergenza chiusa");
	}
	
	public static void pulisciConsole() {										
		System.out.println("------------------------------------------");
		for(int i = 0; i < 3; i++)	System.out.println();
		System.out.println("------------------------------------------");
	}
	
	public static void gestisciAttivita() throws IOException {					
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Campo campo = Campo.instance();
		pulisciConsole();
		String menuAtt = "1: Visualizza tutte le attivit� ATTIVE\n"
						+ "2: Visualizza i VOLONTARI IMPEGNATI in attivit�\n"
						+ "3: Visualizza i VEICOLI IMPEGNATI in attivit�\n"
						+ "4: Visualizza i VOLONTARI DISPONIBILI al campo\n"
						+ "5: Visualizza i VEICOLI DISPONIBILI al campo\n"
						+ "6: Inserisci nuova attivit�\n"
						+ "7: Concludi un'attivit�\n"
						+ "0: ESCI\n";
		System.out.println(menuAtt);
		System.out.println("Selezionare l'operazione da eseguire: ");
		int scelta = Integer.parseInt(br.readLine());
		switch (scelta) {
		case 0:																break;
		case 1:	System.out.println(campo.toStringAttivita());				break;
		case 2:	System.out.println(campo.toStringVolontariImpegnati());		break;
		case 3:	System.out.println(campo.toStringVeicoliImpegnati());		break;
		case 4: System.out.println(campo.toStringVolontariDisponibili()); 	break;
		case 5: System.out.println(campo.toStringVeicoliDisponibili());		break;
		case 6:	campo.nuovaAttivita();										break;
		case 7: campo.concludiAttivita();									break;
		default:System.err.println("Scelta non accettata");					break;
		}
	}
	
	public static void gestisciRimborsi() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Campo campo = Campo.instance();
		pulisciConsole();
		String menuRimb = "1: Calcola rimborso volontario\n"
						+ "2: Calcola rimborso veicolo\n"
						+ "0: ESCI\n";
		System.out.println(menuRimb);
		int scelta = Integer.parseInt(br.readLine());
		/*
		 * Rimborso volontario
		 */
		if(scelta == 1) {
			CalcolaRimborso calcola = new CalcolaRimborso();
			System.out.print("Inserire COGNOME volontario: ");
			String cognome = br.readLine();
			System.out.print("Inserire NOME volontario: ");
			String nome = br.readLine();
			Volontario v = new VolontarioSemplice(cognome, nome);
			int pos = campo.cercaElemento(v, campo.getVolontariDisponibili());
			if(pos == -1) {
				v = new CapoSquadra(cognome, nome, "");
				pos = campo.cercaElemento(v, campo.getVolontariDisponibili());
				if(pos == -1) {
					System.err.println("Volontario non trovato");
				}
				else {
					System.out.println("Rimborso volontario = "+calcola.visit(campo.getVolontariDisponibili().get(pos))+" �");
				}
			}
			else {
				System.out.println("Rimborso volontario = "+calcola.visit(campo.getVolontariDisponibili().get(pos))+" �");
			}
		}
		/*
		 * Rimborso veicolo
		 */
		if(scelta == 2) {
			System.out.print("Inserire la targa del mezzo desiderato: ");
			String targa = br.readLine();
			int pos = campo.cercaElemento(targa.toUpperCase(), campo.getTargheVeicoli());
			if(pos == -1)
				System.err.println("Veicolo non trovato");
			else {
				System.out.println("Rimborso calcolato per il veicolo "+targa+" = "+campo.getVeicoliDisponibili().get(pos).calcolaRimborso()+" �");
			}
		}
	}
	
	public static int stampaMenu() throws IOException {							
		int s;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String stampa = "----- GESTIONE EMERGENZA: -----\n"
						+ "1: STAMPA GRUPPI registrati\n"
						+ "2: STAMPA VOLONTARI registrati\n"
						+ "3: STAMPA VEICOLI registrati\n"
						+ "4: gestisci ATTIVITA\n"
						+ "5: gestisci RIMBORSI\n"
						+ "0: CHIUDI EMERGENZA\n";
		System.out.println(stampa);
		System.out.println("Selezionare l'operazione da eseguire: ");
		s = Integer.parseInt(br.readLine());
		return s;
	}
	
	public static void popolaCampo() {											
		// Istanza static del campo
		Campo campo = Campo.instance();
		/*
		 * GRUPPO GRIFONDORO
		 */
		Volontario v1 = new VolontarioSemplice("Bressanelli", "Giorgia");
		Volontario v2 = new VolontarioSemplice("Rossi", "Mario");
		Volontario v3 = new VolontarioSemplice("Paoletti", "Luca");
		Volontario v4 = new CapoSquadra("Ferrari", "Enzo", "3334446666");		
		Veicolo m1 = new Veicolo("Toyota", "Navara", "AA001BB", 150000, 5);	
		// Creazione dell'oggetto gruppo e popolazione
		Gruppo g1 = new Gruppo("GRIFONDORO");
		g1.aggiungiVolontario(v1);
		g1.aggiungiVolontario(v2);
		g1.aggiungiVolontario(v3);
		g1.aggiungiVolontario(v4);
		// Uso dei metodi overload per inserire altri volontari
		g1.aggiungiVolontario("Arpini", "Marta");
		g1.aggiungiVolontario("Riga", "Fabio", "3333333333");
		g1.aggiungiVeicolo(m1);
		// Registrazione del gruppo nel campo
		campo.ingressoGruppo(g1);
		/*
		 * GRUPPO CORVO NERO
		 */
		Gruppo g2 = new Gruppo("CORVO NERO");
		Volontario v7 = new CapoSquadra("De Santis", "STELLA", "3345556666");
		Volontario v8 = new VolontarioSemplice("Bonissi", "Marco");
		Volontario v9 = new VolontarioSemplice("Bonizzoni", "Marco");
		Veicolo m2 = new Veicolo("IVECO", "Daily", "CD047LL", 25550, 10);
		Veicolo m3 = new Veicolo("Fiat", "Ducato", "AB765KX", 120880, 10);
		g2.aggiungiVolontario(v7);
		g2.aggiungiVolontario(v8);
		g2.aggiungiVolontario(v9);
		g2.aggiungiVeicolo(m2);
		g2.aggiungiVeicolo(m3);
		campo.ingressoGruppo(g2);
		/*
		 * GRUPPO TASSO ROSSO
		 */
		Gruppo g3 = new Gruppo("TASSO ROSSO");
		Volontario v10 = new VolontarioSemplice("Vailati", "Luca");
		Volontario v11 = new VolontarioSemplice("Arpini", "Mario");
		g3.aggiungiVolontario(v10);
		g3.aggiungiVolontario(v11);
		campo.ingressoGruppo(g3);
		/*
		 * GRUPPO SERPE VERDE
		 */
		Gruppo g4 = new Gruppo("Serpeverde");
		g3.aggiungiVolontario("Facchinetti", "Luciana");
		g3.aggiungiVolontario("Verdi", "Silvana");
		g3.aggiungiVolontario("Balla", "Adriana");
		g3.aggiungiVolontario("Fiori", "Viola", "3333000000");
		g3.aggiungiVeicolo(new Veicolo("Ford", "Ranger", "GX077SA", 10000, 3));
		g3.aggiungiVeicolo(new Veicolo("BMW", "Serie 1", "FA946FI", 175500, 13));
		campo.ingressoGruppo(g4);
		/*
		 * CREAZIONE ATTIVITA
		 */
		Attivita a1 = new Attivita("Taglio piante fiume");
		Attivita a2 = new Attivita("Montaggio tende");
		Attivita a3 = new Attivita("Trasporto civili");
		a1.addVolontari(v4, v1, v8);
		a1.addVeicoli(m1);
		a2.addVolontari(v9, v10, v11, v3);
		a3.addVolontari(v7);
		a3.addVeicoli(m3);
		campo.registraAttivita(a1);
		campo.registraAttivita(a2);
		campo.registraAttivita(a3);
	}

}
