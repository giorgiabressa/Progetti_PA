package Emergenza;

/**
 * Classe VEICOLO per la gestione delle operazioni possibili su un singolo veicolo.
 */
public class Veicolo {
	private static final double PREZZO_CARBURANTE = 2.0;
	private String marca;
	private String modello;
	private String targa;
	private boolean inAttivita;
	private double chilometri_veicolo;
	private double chilometri_percorsi;
	private double consumo;

	public Veicolo(String m, String mo, String t, double km, double consumo) {
		this.marca = m.toUpperCase();
		this.modello = mo.toUpperCase();
		this.targa = t.toUpperCase();
		this.inAttivita = false;
		this.chilometri_veicolo = km;
		this.consumo = consumo;
		this.chilometri_percorsi = 0;
	}
	
	/**
	 * METODI GET
	 */
	public double getKmVeicolo()	{ return this.chilometri_veicolo; }
	public double getKmPercorsi()	{ return this.chilometri_percorsi; }
	public String getTarga() 		{ return this.targa; }
	public boolean getStato() 		{ return this.inAttivita; }
	
	/**
	 * METODI PER LA GESTIONE DEL VEICOLO IN ATTIVITA E A FINE ATTIVITA
	 */
	public void inizioAttivita() 	{ this.inAttivita = true; }
	
	public void fineAttivita(double km) {
		this.chilometri_percorsi += km;							//aggiungo i chilometri percorsi durante l'attivit�
		this.inAttivita = false; 
	}
	
	/**
	 * METODO per il calcolo del RIMBORSO sui chilometri percorsi e sul consumo del veicolo
	 */
	public double calcolaRimborso() {
		double rimborso = (PREZZO_CARBURANTE / this.consumo) * this.chilometri_percorsi;
		return rimborso;
	}
	
	/**
	 * METODO PER L'USCITA DEFINITIVA DEL MEZZO
	 */
	public void uscitaDefinitiva() {
		this.inAttivita = false;								//viene reso nuovamente disponibile
		this.chilometri_veicolo += this.chilometri_percorsi;	//i chilometri percorsi diventano effettivi
		this.chilometri_percorsi = 0;
	}
	
	/**
	 * Override del metodo equals
	 */
	public boolean equals(Veicolo v) {
		return this.targa.equals(v.getTarga());
	}
	
	/**
	 * Overrire del metodo toString
	 */
	public String toString() {
		return "Veicolo:\t"+marca+"\t"+modello+"\t"+targa+"\n";
	}
}
