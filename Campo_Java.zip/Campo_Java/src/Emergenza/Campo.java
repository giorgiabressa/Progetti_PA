package Emergenza;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Classe CAMPO che incapsula tutte le operazioni che si possono svolgere in un campo
 */
public class Campo {
	private static Campo campo = null;
	private static ArrayList<Gruppo> gruppi;
	private static ArrayList<Veicolo> veicoli;
	private static ArrayList<Volontario> volontari;
	private static ArrayList<Attivita> activities;
	
	/**
	 * Utilizzo del Singleton
	 */
	private Campo() {	}
	public static Campo instance() {
		if(campo == null) {
			campo = new Campo();
			gruppi = new ArrayList<>();
			veicoli = new ArrayList<>();
			volontari = new ArrayList<>();
			activities = new ArrayList<>();
		}
		
		return campo;
	}
	
	/**
	 * METODI GET SUGLI ARRAYLIST
	 */
	public ArrayList<Veicolo> getVeicoliDisponibili(){	
		ArrayList<Veicolo> disponibili = new ArrayList<>();
		for (Veicolo v : veicoli) {
			if(!v.getStato())
				disponibili.add(v);
		}
		return disponibili; 
	}
	
	public ArrayList<Volontario> getVolontariDisponibili(){
		ArrayList<Volontario> disponibili = new ArrayList<>();
		for (Volontario v : volontari) {
			if(!v.getStato())
				disponibili.add(v);
		}
		return disponibili;
	}
	
	public ArrayList<String> getTargheVeicoli(){
		ArrayList<String> targhe = new ArrayList<>();
		for (Veicolo v : getVeicoliDisponibili())
			targhe.add(v.getTarga());
		return targhe;
	}
	
	/**
	 * METODI PER L'AUTOPOPOLAZIONE: vengono usati nel metodo statico popolaCampo()
	 */
	public void ingressoGruppo(Gruppo gr) {													
		gruppi.add(gr);
		// Registro al campo anche tutti i veicoli e tutti i volontari con cui il gruppo si presenta
		veicoli.addAll(gr.getVeicoli());
		volontari.addAll(gr.getVolontari());
	}
	
	public void registraAttivita(Attivita a) {												
		activities.add(a);
	}
	
	/**
	 * METODI USATI NELLA GESTIONE DEL MENU PRINCIPALE 
	 */
	public void nuovaAttivita() throws IOException {										
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String scelta, cognome, nome, targa;
		System.out.println("Inserire descrizione attivit�: ");
		String desc = br.readLine();
		Attivita a = new Attivita(desc);
		
		//Per la registrazione di una nuova attivit� � necessario che ci sia un caposquadra disponibile
		System.out.println("Inserire COGNOME CAPO SQUADRA: ");
		cognome = br.readLine();
		System.out.println("Inserire NOME CAPO SQUADRA: ");
		nome = br.readLine();
		Volontario c = new CapoSquadra(cognome, nome, " ");
		int pos = cercaElemento(c, getVolontariDisponibili());
		if(pos == -1)
			System.out.println("Capo squadra non disponibile");
		else 
			a.addVolontari(getVolontariDisponibili().get(pos));
		
		//Si passa alla registrazione dei volontari disponibili, deve essercene almeno 1
		do {
			System.out.print("Inserire COGNOME volontario assegnato all'attivit�: ");
			cognome = br.readLine();
			System.out.print("Inserire NOME volontario assegnato all'attivit�: ");
			nome = br.readLine();
			Volontario v = new VolontarioSemplice(cognome, nome);
			pos = cercaElemento(v, getVolontariDisponibili());
			if(pos == -1)
				System.out.println("VOLONTARIO NON DISPONIBILE");
			else 
				a.addVolontari(getVolontariDisponibili().get(pos));
			System.out.println("Inserire un altro volontario? (SI/NO): ");
			scelta = br.readLine();
		}while(scelta.equalsIgnoreCase("si"));
		
		//Si conclude con la registrazione dei mezzi, possono anche non esserci mezzi in un'attivit�
		System.out.println("Aggiungere mezzi all'attivit�? (SI/NO: ");
		scelta = br.readLine();
		while(scelta.equalsIgnoreCase("si")) {
			System.out.println("Inserire la TARGA del mezzo assegnato all'attivit�: ");
			targa = br.readLine();
			pos = cercaElemento(targa.toUpperCase(), getTargheVeicoli());
			if(pos == -1)
				System.err.println("VEICOLO NON DISPONIBILE");
			else 
				a.addVeicoli(getVeicoliDisponibili().get(pos));
			System.out.println("Inserire un altro mezzo? (SI/NO)");
			scelta = br.readLine();
		}
		activities.add(a);
	}
		
	public void concludiAttivita() throws IOException{										
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		for (int i = 0; i < activities.size(); i++) {
			System.err.println("- "+i+": "+activities.get(i).getDesc()+"\n");
		}
		System.out.print("Selezionare l'attivit� da concludere: ");
		int scelta = Integer.parseInt(br.readLine());
		if(scelta >= activities.size())
			System.err.println("ERRORE");
		else {
			//Per concludere l'attivit� � necessario memorizzare i dati che serviranno per i rimborsi
			System.out.println("Inserire le ore di attivit� svolte dai volontari: ");
			int ore = Integer.parseInt(br.readLine());
			System.out.println("Inserire i km percorsi dai mezzi: ");
			double km = Double.parseDouble(br.readLine());
			activities.get(scelta).fineAttivita(ore, km);
			
			activities.remove(scelta);
		}
	}
	
	public void chiusuraEmergenza() throws IOException {
		//Non � possibile chiudere il campo di gestione emergenza se non ancora attive delle attivit�, forza la chiusura
		while(!activities.isEmpty()) {
			System.err.println("CI SONO ANCORA ATTIVITA IN CORSO, IMPOSSIBILE CHIUDERE!");
			concludiAttivita();
		}
		
		for (Gruppo gr : gruppi) {
			gr.uscitaDefinitiva();
		}
		gruppi.clear();
		volontari.clear();
		veicoli.clear();		
	}

	/**
	 * METODI TO STRING
	 */
	public String toString() {																
		String stampa = "Gruppi registrati all'emergenza:\n";
		for (Gruppo g : gruppi)
			stampa += g.toString();
		return stampa;
	}
	
	public String toStringVolontari() {														
		String stampa = "Volontari registrati all'emergenza:\n";
		for (Volontario vol : volontari)
			stampa += vol.toString();
		return stampa;
	}
	
	public String toStringVeicoli() {														
		String stampa = "Veicoli registrati all'emergenza:\n";
		for (Veicolo v : veicoli) 
			stampa += v.toString();
		return stampa;
	}
	
	public String toStringAttivita() {														
		String stampa = "Attivit� attive:\n";
		for (Attivita a : activities)
			stampa += a.getDesc() + "\n";
		return stampa;
	}

	public String toStringVeicoliImpegnati() {												
		String stampa = "Veicoli impegnati in attivit�:\n";
		for (Attivita att : activities)
			stampa += att.toStringVeicoli();	
		return stampa;
	}
	
	public String toStringVeicoliDisponibili() {											
		String stampa = "Veicoli disponibili al campo:\n";
		for (Veicolo v : getVeicoliDisponibili())
			stampa += v.toString();	
		return stampa;
	}

	public String toStringVolontariImpegnati() {											
		String stampa = "Volontari impegnati in attivit�:\n";
		for(Attivita att : activities)
			stampa += att.toStringVolontari();		
		return stampa;
	}
	
	public String toStringVolontariDisponibili() {											
		String stampa = "Volontari disponibili al campo:\n";
		for(Volontario v : getVolontariDisponibili()) 
			stampa += v.toString();
		return stampa;
	}
	
	/**
	 * METODO GENERICO per la ricerca di un elemento, si basa sulla costruzione dei toString all'interno del progetto
	 */
	public <T> int cercaElemento(T elemento, ArrayList<T> elenco) {							
		int pos = -1;
		for (int i = 0; i < elenco.size(); i++) {
			if(elenco.get(i).toString().contains(elemento.toString())) {
				pos = i;
				break;
			}
		}
		return pos;
	}

}