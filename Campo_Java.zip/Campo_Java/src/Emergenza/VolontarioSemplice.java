package Emergenza;

public class VolontarioSemplice extends Volontario {
	
	public VolontarioSemplice(String cognome, String nome) {
		super(cognome, nome);
	}
	
	public double accept(Visitor v) {
		return v.visit(this);
	}
}
