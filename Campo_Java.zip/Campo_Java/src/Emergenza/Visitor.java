package Emergenza;

public interface Visitor {
	public double visit(Volontario v);
	public double visit(VolontarioSemplice vs);
	public double visit(CapoSquadra vcs);	
}
