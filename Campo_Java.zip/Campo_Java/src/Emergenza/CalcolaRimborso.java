package Emergenza;

/**
 * Classe riservata all'operazione di calcolo rimborso sui volontari, sfrutta il Visitor Pattern
 */
public class CalcolaRimborso implements Visitor{

	public double visit(Volontario v) {
		if(v instanceof VolontarioSemplice)
			return this.visit((VolontarioSemplice) v);
		if(v instanceof CapoSquadra)
			return this.visit((CapoSquadra)v);
		else {
			return 0.0;
		}
	}

	/**
	 * VISIT per il VOLONTARIO SEMPLICE: il rimborso � calcolato solo in base alle ore di volontariato prestate.
	 */
	public double visit(VolontarioSemplice vs) {
		return 5.0 * vs.getOre();
	}

	/**
	 * VISIT per il CAPO SQUADRA: il rimborso � calcolato considerando un ulteriore compenso oltre alle ore prestate.
	 */
	public double visit(CapoSquadra vcs) {
		return 5.0 * vcs.getOre() + 15;
	}
}
