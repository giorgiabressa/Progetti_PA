package Emergenza;

/**
 * Classe VOLONTARIO astratta, necessaria per l'eredit� di Volontario Semplice e Capo Squadra.
 */
public abstract class Volontario implements Visitable{
	protected String cognome;
	protected String nome;
	protected boolean inAttivita;
	protected int ore_attivita;
	
	public Volontario(String cognome, String nome) {
		this.cognome = cognome.toUpperCase();
		this.nome = nome.toUpperCase();
		this.inAttivita = false;
		this.ore_attivita = 0;
	}
	
	/**
	 * METODO ACCEPT per permettere l'utilizzo del Visitor Pattern
	 */
	public abstract double accept(Visitor v);
	
	/**
	 * METODI GET
	 */
	public String getNome() 	{	return this.nome;		}
	public String getCognome() 	{	return this.cognome;	}
	public boolean getStato()	{	return this.inAttivita;	}
	public int getOre()			{	return this.ore_attivita; }
	
	/**
	 * METODI PER LA GESTIONE DEI VOLONTARI IN ATTIVITA E A FINE ATTIVITA
	 */
	public void inizioAttivita(){	this.inAttivita = true;	}
	
	public void fineAttivita(int ore){	
		this.ore_attivita += ore;						//aggiungo le ore prestate durante l'attivit�
		this.inAttivita = false;
	}
	
	/**
	 * METODO PER L'USCITA DEFINITIVA DEL VOLONTARIO
	 */
	public void uscitaDefinitiva() {					//a differenza del veicolo, un volontario non ha ore accumulate
		this.inAttivita = false;					
		this.ore_attivita = 0;
	}
	
	/**
	 * Override del metodo toString()
	 */
	public String toString() {
		return "Volontario:\t"+cognome+"\t"+nome+"\n";
	}
}
